<?php
require_once 'config/database.php';
echo json_encode(['status' => 'ok', 'mensagem' => 'Conexão com o banco funcionando']);