<?php
// Credenciais do banco de dados - NÃO subir para o GitHub
$host = 'localhost';
$dbname = 'safeincident';
$usuario = 'root';
$senha = ''; // XAMPP por padrão usa senha vazia para o root

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $usuario,
        $senha,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION] // faz erros de SQL lançarem exceção, em vez de falhar silenciosamente
    );
} catch (PDOException $e) {
    http_response_code(500);
    die(json_encode(['erro' => 'Falha na conexão com o banco: ' . $e->getMessage()]));
}